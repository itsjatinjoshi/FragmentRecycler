package com.example.fragmentrecycler;

import android.app.Application;

import java.util.ArrayList;

public class ApplicationClass extends Application {
    public static ArrayList<Person> people;

    @Override
    public void onCreate() {
        super.onCreate();

        people= new ArrayList<Person>();
        people.add(new Person("abcd efgh", "232323232"));
        people.add(new Person("hello dear", "2w2323232323"));
        people.add(new Person("Jatin Joshi", "21231224555"));

    }
}

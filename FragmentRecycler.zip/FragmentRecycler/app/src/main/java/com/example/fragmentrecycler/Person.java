package com.example.fragmentrecycler;

public class Person {

   private String Name;
   private String tellNum;

    public Person(String name, String tellNum) {
        Name = name;
        this.tellNum = tellNum;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getTellNum() {
        return tellNum;
    }

    public void setTellNum(String tellNum) {
        this.tellNum = tellNum;
    }
}

package com.example.fragmentrecycler;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements personAdapter.ItemClicked {

    TextView tvName, tvNum;
    EditText etName, etNum;
    Button addBtn;
    ListFrag listFrag;
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvName= findViewById(R.id.tvName);
        tvNum= findViewById(R.id.tvNum);
        etName= findViewById(R.id.etName);
        etNum= findViewById(R.id.etNum);

        addBtn= findViewById(R.id.addBtn);
        fragmentManager = this.getSupportFragmentManager();
        listFrag= (ListFrag) fragmentManager.findFragmentById(R.id.listFrag) ;

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(etName.getText().toString().isEmpty() || etNum.getText().toString().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please enter all the fields !", Toast.LENGTH_SHORT).show();
                }
                else{
                    ApplicationClass.people.add(new Person(etName.getText().toString().trim(), etNum.getText().toString().trim()));
                    Toast.makeText(MainActivity.this, "Person Successfully Added !", Toast.LENGTH_SHORT).show();
                    etName.setText(null);
                    etNum.setText(null);
                    listFrag.notifyDataChannged();
                }
            }
        });
        onItemClicked(0);
    }

    @Override
    public void onItemClicked(int index) {

        tvName.setText(ApplicationClass.people.get(index).getName());
        tvNum.setText(ApplicationClass.people.get(index).getTellNum());
    }
}
